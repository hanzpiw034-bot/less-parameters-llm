export default {
  BOT_TOKEN: '8542163923:AAEo-efwiFbD67ezBAmrCUgDO8CoagHy7FA', // GANTI TOKEN LU
  BOT_NAME: '☬ | 𝗕𝗢𝗧 𝗚𝗔𝗖𝗛𝗔 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 | ☬',
  BOT_USERNAME: 'HanzPiwGachaBot', 
  CHANNEL_ID: '@abouthanzpiw',
  OWNER_USERNAME: 'hanzxstr', //tanpa @
  ADMIN_IDS: [7135669179], // ID Admin
  GACHA_LIMIT: 50 // Jangan Di Ubah
};

// Thank To Buy Script Gacha 